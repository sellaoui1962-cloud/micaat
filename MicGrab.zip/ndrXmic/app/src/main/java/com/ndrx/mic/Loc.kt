package com.ndrx.mic

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object Loc {
    fun lang(): String {
        val v = Prefs.lang
        if (v != null) return v
        return if (Locale.getDefault().language == "ar") "ar" else "en"
    }

    fun isAr(): Boolean = lang() == "ar"

    fun wrap(base: Context): Context {
        val l = Locale(lang())
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(l)
        cfg.setLayoutDirection(l)
        return base.createConfigurationContext(cfg)
    }
}
