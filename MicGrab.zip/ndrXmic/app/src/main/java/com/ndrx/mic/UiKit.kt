package com.ndrx.mic

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.widget.TextView

object UiKit {
    val BG = 0xFF070A0D.toInt()
    val CARD = 0xFF0F151A.toInt()
    val STROKE = 0xFF1C2830.toInt()
    val ACCENT = 0xFF39FF88.toInt()
    val ACCENT_DIM = 0xFF123D26.toInt()
    val TEXT = 0xFFE6EDF3.toInt()
    val MUTED = 0xFF8A99A6.toInt()
    val DANGER = 0xFFFF3B5C.toInt()
    val BLUE = 0xFF3FA9FF.toInt()
    val YELLOW = 0xFFFFD23F.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun bg(c: Context, color: Int, rDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, rDp).toFloat()
        if (strokeDp > 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    fun pressable(normal: Drawable, pressed: Drawable): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), pressed)
        s.addState(intArrayOf(), normal)
        return s
    }

    fun tv(c: Context, text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
        val t = TextView(c)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = when {
            mono -> Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
            bold -> Typeface.DEFAULT_BOLD
            else -> Typeface.DEFAULT
        }
        return t
    }
}
