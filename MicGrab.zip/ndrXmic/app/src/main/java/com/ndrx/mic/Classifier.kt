package com.ndrx.mic

import java.nio.ByteBuffer

class Frame(val buf: ByteBuffer, val w: Int, val h: Int, val rs: Int, val ps: Int) {
    fun lum(x: Int, y: Int): Float {
        val xx = if (x < 0) 0 else if (x >= w) w - 1 else x
        val yy = if (y < 0) 0 else if (y >= h) h - 1 else y
        val o = yy * rs + xx * ps
        return 0.299f * (buf.get(o).toInt() and 0xFF) +
            0.587f * (buf.get(o + 1).toInt() and 0xFF) +
            0.114f * (buf.get(o + 2).toInt() and 0xFF)
    }
}

object Classifier {
    const val LOCKED = 0
    const val EMPTY = 1
    const val OCC = 2
    const val UNK = 3

    private const val G = 16
    private val tl = Templates.tl
    private val te = Templates.te
    private val tmp = FloatArray(G * G)
    private val sc = FloatArray(2)

    /** Normalized correlation with the lock and mic templates. */
    private fun score(f: Frame, cx: Float, cy: Float, r: Float, out: FloatArray) {
        val step = 2f * Templates.SPAN * r / (G - 1)
        var k = 0
        var sum = 0f
        for (j in 0 until G) {
            val y = Math.round(cy + (j - (G - 1) / 2f) * step)
            for (i in 0 until G) {
                val x = Math.round(cx + (i - (G - 1) / 2f) * step)
                val v = f.lum(x, y)
                tmp[k++] = v
                sum += v
            }
        }
        val mean = sum / (G * G)
        var nn = 0f
        var dl = 0f
        var de = 0f
        for (q in 0 until G * G) {
            val v = tmp[q] - mean
            nn += v * v
            dl += v * tl[q]
            de += v * te[q]
        }
        if (nn < 1e-3f) { out[0] = 0f; out[1] = 0f; return }
        val inv = 1f / Math.sqrt(nn.toDouble()).toFloat()
        out[0] = dl * inv
        out[1] = de * inv
    }

    private fun decide(a: Float, b: Float): Int {
        val m = if (a > b) a else b
        return when {
            a >= 0.6f && a - b >= 0.2f -> LOCKED
            b >= 0.6f && b - a >= 0.2f -> EMPTY
            m < 0.5f -> OCC
            else -> UNK
        }
    }

    /** off = cached alignment offset (frame pixels), refined in place when a strong match is found. */
    fun classify(f: Frame, cx: Float, cy: Float, r: Float, off: IntArray): Int {
        score(f, cx + off[0], cy + off[1], r, sc)
        var bm = if (sc[0] > sc[1]) sc[0] else sc[1]
        if (bm >= 0.8f) return decide(sc[0], sc[1])
        var ba = sc[0]
        var bb = sc[1]
        var bx = off[0]
        var by = off[1]
        val ox = off[0]
        val oy = off[1]
        var dy = -4
        while (dy <= 4) {
            var dx = -4
            while (dx <= 4) {
                score(f, cx + ox + dx, cy + oy + dy, r, sc)
                val m = if (sc[0] > sc[1]) sc[0] else sc[1]
                if (m > bm) { bm = m; ba = sc[0]; bb = sc[1]; bx = ox + dx; by = oy + dy }
                dx += 2
            }
            dy += 2
        }
        val cx0 = bx
        val cy0 = by
        for (ddy in -1..1) {
            for (ddx in -1..1) {
                if (ddx == 0 && ddy == 0) continue
                score(f, cx + cx0 + ddx, cy + cy0 + ddy, r, sc)
                val m = if (sc[0] > sc[1]) sc[0] else sc[1]
                if (m > bm) { bm = m; ba = sc[0]; bb = sc[1]; bx = cx0 + ddx; by = cy0 + ddy }
            }
        }
        if (bm >= 0.8f) {
            off[0] = bx.coerceIn(-10, 10)
            off[1] = by.coerceIn(-10, 10)
        }
        return decide(ba, bb)
    }
}
