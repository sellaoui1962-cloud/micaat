package com.micgrab

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class ClickService : AccessibilityService() {
    companion object {
        @Volatile var instance: ClickService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun tap(x: Float, y: Float, twice: Boolean) {
        val path = Path().apply { moveTo(x, y) }
        val b = GestureDescription.Builder()
        b.addStroke(GestureDescription.StrokeDescription(path, 0, 10))
        if (twice) b.addStroke(GestureDescription.StrokeDescription(path, 90, 10))
        dispatchGesture(b.build(), null, null)
    }
}
