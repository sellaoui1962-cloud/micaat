package com.micgrab

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class CaptureService : Service() {

    // ===== إعدادات يمكن تعديلها =====
    private val cols = floatArrayOf(0.10f, 0.30f, 0.50f, 0.70f, 0.90f)   // مواضع المايكات أفقياً (نسبة من العرض)
    private val rows = floatArrayOf(0.3446f, 0.4571f)                      // مواضع الصفين (نسبة من الارتفاع)
    private val micRadius = 0.07f      // نصف قطر المايك كنسبة من العرض
    private val pixelDiff = 45         // فرق اللون الذي يعتبر "تغيّر" لنقطة واحدة
    private val minChanged = 12        // عدد النقاط المتغيرة (من 81) لاعتبار المايك مفتوحاً
    private val cooldownMs = 2500L     // مهلة بعد الضغط لمنع التكرار
    // =================================

    private val grid = 9
    private val perMic = grid * grid
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var statusView: TextView? = null

    @Volatile private var armed = false
    @Volatile private var calibrate = false
    @Volatile private var baseline: IntArray? = null
    @Volatile private var cooldownUntil = 0L

    private var w = 0
    private var h = 0
    private lateinit var px: IntArray
    private lateinit var py: IntArray
    private lateinit var tapX: FloatArray
    private lateinit var tapY: FloatArray

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        startAsForeground()
        val code = intent.getIntExtra("code", 0)
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        thread = HandlerThread("capture").also { it.start() }
        val bg = Handler(thread!!.looper)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, bg)
        setupCapture(bg)
        showOverlay()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mg", "MicGrab", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "mg")
            .setContentTitle("MicGrab يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun setupCapture(bg: Handler) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels / 2
        h = dm.heightPixels / 2

        val n = cols.size * rows.size
        px = IntArray(n * perMic); py = IntArray(n * perMic)
        tapX = FloatArray(n); tapY = FloatArray(n)
        val step = micRadius * w * 0.12f
        for (r in rows.indices) for (c in cols.indices) {
            val m = r * cols.size + c
            val cx = cols[c] * w
            val cy = rows[r] * h
            tapX[m] = cols[c] * dm.widthPixels
            tapY[m] = rows[r] * dm.heightPixels
            var k = 0
            for (gy in 0 until grid) for (gx in 0 until grid) {
                px[m * perMic + k] = (cx + (gx - grid / 2) * step).toInt().coerceIn(0, w - 1)
                py[m * perMic + k] = (cy + (gy - grid / 2) * step).toInt().coerceIn(0, h - 1)
                k++
            }
        }

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "mg", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, bg
        )
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try { process(img) } finally { img.close() }
        }, bg)
    }

    private fun sample(img: Image): IntArray {
        val p = img.planes[0]
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        val out = IntArray(px.size * 3)
        for (i in px.indices) {
            val o = py[i] * rs + px[i] * ps
            out[i * 3] = buf.get(o).toInt() and 0xFF
            out[i * 3 + 1] = buf.get(o + 1).toInt() and 0xFF
            out[i * 3 + 2] = buf.get(o + 2).toInt() and 0xFF
        }
        return out
    }

    private fun process(img: Image) {
        if (!armed && !calibrate) return
        val cur = sample(img)
        if (calibrate) {
            baseline = cur
            calibrate = false
            setStatus("تمت المعايرة ✔")
            return
        }
        val base = baseline ?: return
        val now = SystemClock.uptimeMillis()
        if (now < cooldownUntil) return
        val mics = tapX.size
        for (m in 0 until mics) {
            var changed = 0
            for (j in 0 until perMic) {
                val i = (m * perMic + j) * 3
                val d = abs(cur[i] - base[i]) + abs(cur[i + 1] - base[i + 1]) + abs(cur[i + 2] - base[i + 2])
                if (d > pixelDiff) changed++
            }
            if (changed >= minChanged) {
                val twice = getSharedPreferences("p", MODE_PRIVATE).getBoolean("double", false)
                ClickService.instance?.tap(tapX[m], tapY[m], twice)
                cooldownUntil = now + cooldownMs
                setStatus("ضغطت المايك ${m + 1}")
                return
            }
        }
    }

    private fun setStatus(s: String) { main.post { statusView?.text = s } }

    private fun showOverlay() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(8, 8, 8, 8)
        }
        val st = TextView(this).apply {
            text = "⠿ اسحب | غير معاير"
            setTextColor(Color.WHITE)
            textSize = 11f
        }
        statusView = st
        val toggle = Button(this).apply { text = "تشغيل"; textSize = 11f }
        toggle.setOnClickListener {
            if (baseline == null) { setStatus("عاير أولاً"); return@setOnClickListener }
            armed = !armed
            toggle.text = if (armed) "إيقاف" else "تشغيل"
            setStatus(if (armed) "يعمل ●" else "متوقف")
        }
        val cal = Button(this).apply { text = "معايرة"; textSize = 11f }
        cal.setOnClickListener { calibrate = true; setStatus("جارٍ المعايرة...") }
        val close = Button(this).apply { text = "إغلاق"; textSize = 11f }
        close.setOnClickListener { stopSelf() }
        box.addView(st); box.addView(cal); box.addView(toggle); box.addView(close)

        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = (dm.heightPixels * 0.17f).toInt() }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        st.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }
        wm.addView(box, lp)
        overlay = box
    }

    override fun onDestroy() {
        armed = false
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}
