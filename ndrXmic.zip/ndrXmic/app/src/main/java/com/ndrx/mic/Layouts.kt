package com.ndrx.mic

/** Coordinates are in "W units": pixels divided by the screen width (both axes). */
data class Slot(val x: Float, val y: Float, val r: Float, val host: Boolean = false)

class Layout(val id: String, val nameRes: Int, val slots: List<Slot>)

object Layouts {
    private const val SM = 0.0694f
    private val X5 = floatArrayOf(0.9f, 0.7f, 0.5f, 0.3f, 0.1f)          // right -> left
    private val X4 = floatArrayOf(0.875f, 0.625f, 0.375f, 0.125f)
    private const val Y1 = 0.5157f
    private const val Y2 = 0.7657f
    private const val Y3 = 1.0157f

    private fun row(xs: FloatArray, y: Float): List<Slot> = xs.map { Slot(it, y, SM) }

    val presets: List<Layout> by lazy {
        listOf(
            Layout("g2x5", R.string.lay_2x5, row(X5, Y1) + row(X5, Y2)),
            Layout("g3x5", R.string.lay_3x5, row(X5, Y1) + row(X5, Y2) + row(X5, Y3)),
            Layout("g1x5", R.string.lay_1x5, row(X5, Y1)),
            Layout("host10", R.string.lay_host10, listOf(Slot(0.5f, Y1, 0.09f, true)) + row(X5, Y2) + row(X5, Y3)),
            Layout("big4", R.string.lay_big4, listOf(Slot(0.5f, 0.5352f, 0.0833f)) + row(X4, 0.8148f)),
            Layout("wave10", R.string.lay_wave10, listOf(Slot(0.625f, Y1, SM), Slot(0.375f, Y1, SM)) + row(X4, Y2) + row(X4, Y3))
        )
    }

    fun parse(s: String): List<Slot> {
        if (s.isBlank()) return emptyList()
        val out = ArrayList<Slot>()
        for (t in s.split(";")) {
            val p = t.split(",")
            if (p.size >= 3) {
                try { out.add(Slot(p[0].toFloat(), p[1].toFloat(), p[2].toFloat())) } catch (_: Exception) {}
            }
        }
        return out
    }

    fun serialize(l: List<Slot>): String = l.joinToString(";") { "${it.x},${it.y},${it.r}" }

    fun custom(): Layout = Layout("custom", R.string.lay_custom, parse(Prefs.custom))

    fun all(): List<Layout> = presets + custom()

    fun current(): Layout {
        val id = Prefs.layoutId
        if (id == "custom") {
            val c = custom()
            if (c.slots.isNotEmpty()) return c
        }
        return presets.firstOrNull { it.id == id } ?: presets[0]
    }

    /** Reading order of the game: top to bottom, right to left. */
    fun sortReading(p: List<Slot>): List<Slot> {
        val byY = p.sortedBy { it.y }
        val rows = ArrayList<MutableList<Slot>>()
        for (s in byY) {
            val last = rows.lastOrNull()
            if (last != null && Math.abs(s.y - last.map { it.y }.average().toFloat()) < 0.07f) last.add(s)
            else rows.add(mutableListOf(s))
        }
        return rows.flatMap { r -> r.sortedByDescending { it.x } }
    }
}
