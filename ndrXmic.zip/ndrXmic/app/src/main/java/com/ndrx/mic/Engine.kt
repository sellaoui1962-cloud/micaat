package com.ndrx.mic

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

object Engine {
    const val OPEN = 0
    const val FOLLOW = 1
    const val PAD = 2

    @Volatile var mode = OPEN
    @Volatile var armed = false
    @Volatile var capturing = false
    @Volatile var screenW = 1080f
    @Volatile var frameW = 0

    var slots: List<Slot> = emptyList()
        private set
    var onStatus: ((String) -> Unit)? = null

    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())
    private var raw = IntArray(0)
    private var stable = IntArray(0)
    private var cand = IntArray(0)
    private var candN = IntArray(0)
    private var offs: Array<IntArray> = emptyArray()
    private var cooldownUntil = 0L
    private var confirm = 1
    private var cooldown = 3000
    private var retry = true
    private var dbl = false

    fun load() {
        mode = Prefs.mode
        confirm = Prefs.confirm
        cooldown = Prefs.cooldown
        retry = Prefs.retry
        dbl = Prefs.doubleTap
        val m = App.ctx.resources.displayMetrics
        screenW = Math.min(m.widthPixels, m.heightPixels).toFloat()
        setLayout(Layouts.current())
    }

    private fun setLayout(l: Layout) {
        synchronized(lock) {
            slots = l.slots
            val n = slots.size
            raw = IntArray(n) { Classifier.UNK }
            stable = IntArray(n) { -1 }
            cand = IntArray(n) { -1 }
            candN = IntArray(n)
            offs = Array(n) { IntArray(2) }
        }
    }

    fun snapshot(): IntArray = synchronized(lock) { raw.copyOf() }

    private fun status(s: String) { onStatus?.invoke(s) }

    fun onFrame(f: Frame) {
        if (mode == PAD) return
        synchronized(lock) {
            frameW = f.w
            val n = slots.size
            if (n == 0) return
            val fw = f.w.toFloat()
            val prev = stable.copyOf()
            for (i in 0 until n) {
                val s = slots[i]
                raw[i] = Classifier.classify(f, s.x * fw, s.y * fw, s.r * fw, offs[i])
            }
            val ch = BooleanArray(n)
            for (i in 0 until n) {
                val r = raw[i]
                if (r == Classifier.UNK) { cand[i] = -1; candN[i] = 0; continue }
                if (stable[i] == -1) { stable[i] = r; continue }
                if (r == stable[i]) { cand[i] = -1; candN[i] = 0; continue }
                if (r == cand[i]) candN[i]++ else { cand[i] = r; candN[i] = 1 }
                if (candN[i] >= confirm) { stable[i] = r; cand[i] = -1; candN[i] = 0; ch[i] = true }
            }
            if (!armed) return
            val now = SystemClock.uptimeMillis()
            if (now < cooldownUntil) return

            if (mode == OPEN) {
                // locked -> open : go down right there (mics that were already open are ignored)
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.LOCKED && stable[i] == Classifier.EMPTY && !slots[i].host) {
                        fire(i, now)
                        return
                    }
                }
            } else if (mode == FOLLOW) {
                // everyone empty, then someone steps up -> take another free mic right after
                var trig = -1
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.EMPTY && stable[i] == Classifier.OCC && !slots[i].host) { trig = i; break }
                }
                if (trig >= 0) {
                    var clean = true
                    for (k in 0 until n) {
                        if (!slots[k].host && prev[k] == Classifier.OCC) { clean = false; break }
                    }
                    if (clean) {
                        for (d in 1 until n) {
                            val t = (trig + d) % n
                            if (!slots[t].host && stable[t] == Classifier.EMPTY) { fire(t, now); return }
                        }
                    }
                }
            }
        }
    }

    private fun fire(i: Int, now: Long) {
        cooldownUntil = now + cooldown
        tapSlot(i)
        status(Loc.wrap(App.ctx).getString(R.string.p_grab, i + 1))
        if (retry) {
            main.postDelayed({
                val st = synchronized(lock) { if (i < stable.size) stable[i] else -1 }
                if (armed && st == Classifier.EMPTY) tapSlot(i)
            }, 350)
        }
    }

    /** Taps the seat number i (0-based). Used by every mode and by the number pad. */
    fun tapSlot(i: Int) {
        val s = slots.getOrNull(i) ?: return
        val svc = ClickService.instance ?: return
        val o = offs.getOrNull(i)
        val fw = frameW
        val k = if (fw > 0) screenW / fw else 1f
        val px = s.x * screenW + (o?.get(0) ?: 0) * k
        val py = s.y * screenW + (o?.get(1) ?: 0) * k
        svc.tap(px, py, dbl)
    }
}
