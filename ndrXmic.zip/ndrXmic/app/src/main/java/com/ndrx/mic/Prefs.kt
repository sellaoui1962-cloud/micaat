package com.ndrx.mic

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    fun sp(): SharedPreferences = App.ctx.getSharedPreferences("ndrx", Context.MODE_PRIVATE)

    var mode: Int
        get() = sp().getInt("mode", 0)
        set(v) { sp().edit().putInt("mode", v).apply() }
    var layoutId: String
        get() = sp().getString("layout", "g2x5") ?: "g2x5"
        set(v) { sp().edit().putString("layout", v).apply() }
    var custom: String
        get() = sp().getString("custom", "") ?: ""
        set(v) { sp().edit().putString("custom", v).apply() }
    var confirm: Int
        get() = sp().getInt("confirm", 1)
        set(v) { sp().edit().putInt("confirm", v).apply() }
    var cooldown: Int
        get() = sp().getInt("cooldown", 3000)
        set(v) { sp().edit().putInt("cooldown", v).apply() }
    var padSize: Int
        get() = sp().getInt("padSize", 1)
        set(v) { sp().edit().putInt("padSize", v).apply() }
    var retry: Boolean
        get() = sp().getBoolean("retry", true)
        set(v) { sp().edit().putBoolean("retry", v).apply() }
    var doubleTap: Boolean
        get() = sp().getBoolean("double", false)
        set(v) { sp().edit().putBoolean("double", v).apply() }
    var dots: Boolean
        get() = sp().getBoolean("dots", false)
        set(v) { sp().edit().putBoolean("dots", v).apply() }
    var lang: String?
        get() = sp().getString("lang", null)
        set(v) { sp().edit().putString("lang", v).apply() }
}
